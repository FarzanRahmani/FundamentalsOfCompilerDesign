// Hello world this is a simple java program 

/* abc
 * def ghijk lmnop
 * qrstuv wxyz
 * 99521271
 */

// Hello word class 
class HelloWorld {

    /* main function */
    public static void main(String[] args) {
        // Prints "Hello, World" to the terminal window.
        System.out.println("Hello, World! It's Farzan Rahmani");
    }
}

/*
    GoodBye World
    Farzan Rahmani
*/